// fomrula de heron: A = (S (s - a) (s - b) (s - c))^1/2
// donde s es: s = (a + b + c) / 2

function calculArea(a , b, c) {
    const s = (a + b + c) / 2
    return Math.sqrt((s * (s - a) * (s - b) * (s - c)))
}

module.exports = calculArea