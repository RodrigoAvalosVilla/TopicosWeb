const calculArea = require('./heron')

test('a: 13 | b: 15 | c: 14', () => {
    expect(calculArea(13, 15, 14)).toBe(84)
})

test('a: 10 | b: 5 | c: 6', () => {
    expect(calculArea(10, 5, 6)).toBe(11.399013115177997)
})

test('a: 4 | b: 4 | c: 4', () => {
    expect(calculArea(4, 4, 4)).toBe(6.928203230275509)
})